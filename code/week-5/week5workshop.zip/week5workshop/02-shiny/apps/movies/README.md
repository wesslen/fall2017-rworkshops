A series of simple Shiny apps that display data from a random sample of 651 movies released in the US between 1970 and 2014. Data come from IMDB and Rotten Tomatoes. Used in Shiny training materials.
