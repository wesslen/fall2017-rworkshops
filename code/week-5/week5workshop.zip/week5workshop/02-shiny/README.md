# Introduction to Shiny

Apps used in demos during the webinar are in the apps folder. Make sure you have the required packages installed.

Slides are in intro-to-shiny.PDF.
