# Tidyverse, visualisation, and manipulation basics

To view the code demos, open **Tidyverse-webinar > Tidyverse-webinar.Rmd** in the RStudio IDE. Then click the **Run Document** button that appears at the top of the file.

* Each code block contains the initial unaltered code that I began with in the webinaar.

* Where appropriate, code chunks contain a _solution_ button that contains the final code that I wrote for the exercise. Click on the button to see the code.

* Write your own code in the code chunks. Click _Run_ to run it.